const db = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
    static async create(userData) {
        const {
            firstname,
            lastname,
            email,
            phonenumber,
            address,
            password,
            dob
        } = userData;

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        const query = `
            INSERT INTO users (firstname, lastname, email, phonenumber, address, password, dob)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        return new Promise((resolve, reject) => {
            db.execute(
                query,
                [firstname, lastname, email, phonenumber, address, hashedPassword, dob],
                (err, results) => {
                    if (err) reject(err);
                    resolve(results);
                }
            );
        });
    }

    static async findByEmail(email) {
        const query = 'SELECT * FROM users WHERE email = ?';
        
        return new Promise((resolve, reject) => {
            db.execute(query, [email], (err, results) => {
                if (err) reject(err);
                resolve(results[0]);
            });
        });
    }

    static async getAll() {
        const query = 'SELECT id, firstname, lastname, email, phonenumber, address, dob, created_at FROM users';
        
        return new Promise((resolve, reject) => {
            db.execute(query, (err, results) => {
                if (err) reject(err);
                resolve(results);
            });
        });
    }
}

module.exports = User;