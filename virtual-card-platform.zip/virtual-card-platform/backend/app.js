﻿const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Import routes
const authRoutes = require('./routes/users');  // This handles /register and /login
const userRoutes = require('./routes/userRoutes');  // This handles /users

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/v1/api/auth', authRoutes);
app.use('/v1/api/users', userRoutes);

// Test route
app.get('/', (req, res) => {
    res.json({ 
        message: 'Virtual Card Platform API is running!',
        endpoints: {
            register: 'POST /v1/api/auth/register',
            login: 'POST /v1/api/auth/login', 
            getUsers: 'GET /v1/api/users'
        }
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Virtual Card Platform Server running on port ${PORT}`);
    console.log(`📝 Endpoints:`);
    console.log(`   POST http://localhost:${PORT}/v1/api/auth/register`);
    console.log(`   POST http://localhost:${PORT}/v1/api/auth/login`);
    console.log(`   GET  http://localhost:${PORT}/v1/api/users`);
    console.log(`🔗 Test with: http://localhost:${PORT}/`);
});