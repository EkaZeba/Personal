import React, { useState, useEffect } from 'react';
import Dashboard from './components/Dashboard';
import Header from './components/Header';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [cards, setCards] = useState([]);

  useEffect(() => {
    setUser({
      id: 1,
      name: 'Jerome Depp',
      email: 'deppjerome@gmail.com',
      kycStatus: 'verified'
    });
    
    // Mock initial cards data
    const mockCards = [
      {
        id: 1,
        cardNumber: '**** **** **** 1234',
        expiryDate: '12/25',
        cvv: '***',
        balance: 1500.00,
        currency: 'USD',
        status: 'active',
        spendingLimit: 2000.00,
        usedAmount: 500.00
      },
      {
        id: 2,
        cardNumber: '**** **** **** 5678',
        expiryDate: '06/26',
        cvv: '***',
        balance: 800.00,
        currency: 'USD',
        status: 'active',
        spendingLimit: 1000.00,
        usedAmount: 200.00
      }
    ];
    setCards(mockCards);
  }, []);

  const handleCreateCard = async (cardData) => {
    const newCard = {
      id: cards.length + 1,
      cardNumber: '**** **** **** ' + Math.floor(1000 + Math.random() * 9000),
      expiryDate: '12/26',
      cvv: '***',
      ...cardData,
      status: 'active',
      usedAmount: 0
    };
    setCards([...cards, newCard]);
  };

  const handleToggleCard = (cardId) => {
    setCards(cards.map(card => 
      card.id === cardId 
        ? { ...card, status: card.status === 'active' ? 'frozen' : 'active' }
        : card
    ));
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="app">
      <Header user={user} />
      <div className="app-content">
        <Dashboard 
          cards={cards}
          onCreateCard={handleCreateCard}
          onToggleCard={handleToggleCard}
          user={user}
        />
      </div>
    </div>
  );
}

export default App;
