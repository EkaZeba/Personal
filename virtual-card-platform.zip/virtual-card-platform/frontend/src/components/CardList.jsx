import React from 'react';

const CardList = ({ cards, onToggleCard }) => {
  if (cards.length === 0) {
    return (
      <div className="empty-state">
        <h3>No virtual cards yet</h3>
        <p>Create your first virtual card to get started</p>
      </div>
    );
  }

  return (
    <div className="card-list">
      {cards.map(card => (
        <div key={card.id} className={`card-item ${card.status}`}>
          <div className="card-header">
            <h3>Virtual Card {card.id}</h3>
            <span className={`card-status ${card.status}`}>
              {card.status}
            </span>
          </div>
          
          <div className="card-details">
            <div className="card-number">{card.cardNumber}</div>
            <div className="card-info">
              <span>Expires: {card.expiryDate}</span>
              <span>CVV: {card.cvv}</span>
            </div>
          </div>
          
          <div className="card-balance">
            <div className="balance">Balance: ${card.balance.toFixed(2)}</div>
            <div className="spending-limit">
              Limit: ${card.spendingLimit.toFixed(2)} 
              (Used: ${card.usedAmount.toFixed(2)})
            </div>
          </div>
          
          <div className="card-actions">
            <button 
              className={`btn-secondary ${card.status === 'active' ? 'freeze' : 'activate'}`}
              onClick={() => onToggleCard(card.id)}
            >
              {card.status === 'active' ? 'Freeze Card' : 'Activate Card'}
            </button>
            <button className="btn-secondary">View Details</button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CardList;
