import React from 'react';

const Header = ({ user }) => {
  return (
    <header className="header">
      <div className="header-content">
        <div className="logo">
          <h1>Virtual Card Platform</h1>
        </div>
        <div className="user-info">
          <span>  Welcome, {user.name}</span>
          <div className={`kyc-status ${user.kycStatus}`}>
            KYC: {user.kycStatus}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
