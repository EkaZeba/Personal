import React, { useState } from 'react';
import CardList from './CardList';
import CardForm from './CardForm';

const Dashboard = ({ cards, onCreateCard, onToggleCard, user }) => {
  const [showCardForm, setShowCardForm] = useState(false);

  const totalBalance = cards.reduce((sum, card) => sum + card.balance, 0);
  const activeCards = cards.filter(card => card.status === 'active').length;

  return (
    <div className="dashboard">
      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>Total Balance</h3>
          <p className="amount">${totalBalance.toFixed(2)}</p>
        </div>
        <div className="stat-card">
          <h3>Active Cards</h3>
          <p className="count">{activeCards}</p>
        </div>
        <div className="stat-card">
          <h3>KYC Status</h3>
          <p className={`status ${user.kycStatus}`}>{user.kycStatus}</p>
        </div>
      </div>

      <div className="section-header">
        <h2>Virtual Cards</h2>
        <button 
          className="btn-primary"
          onClick={() => setShowCardForm(true)}
        >
          + Create New Card
        </button>
      </div>
      
      {showCardForm && (
        <CardForm 
          onSubmit={onCreateCard}
          onCancel={() => setShowCardForm(false)}
        />
      )}
      
      <CardList 
        cards={cards} 
        onToggleCard={onToggleCard}
      />
    </div>
  );
};

export default Dashboard;
