import React, { useState } from 'react';

const CardForm = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    spendingLimit: '',
    currency: 'USD',
    expirationMonths: 12
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      spendingLimit: parseFloat(formData.spendingLimit),
      balance: parseFloat(formData.spendingLimit)
    });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="card-form-overlay">
      <form className="card-form" onSubmit={handleSubmit}>
        <h3>Create New Virtual Card</h3>
        
        <div className="form-group">
          <label>Spending Limit ($)</label>
          <input
            type="number"
            name="spendingLimit"
            value={formData.spendingLimit}
            onChange={handleChange}
            placeholder="Enter spending limit"
            required
            min="1"
          />
        </div>
        
        <div className="form-group">
          <label>Currency</label>
          <select 
            name="currency" 
            value={formData.currency}
            onChange={handleChange}
          >
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Card Validity (Months)</label>
          <select 
            name="expirationMonths" 
            value={formData.expirationMonths}
            onChange={handleChange}
          >
            <option value={6}>6 Months</option>
            <option value={12}>12 Months</option>
            <option value={24}>24 Months</option>
          </select>
        </div>
        
        <div className="form-actions">
          <button type="button" className="btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="btn-primary">
            Create Card
          </button>
        </div>
      </form>
    </div>
  );
};

export default CardForm;
